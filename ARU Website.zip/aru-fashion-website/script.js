// ARU: beginner-friendly fashion gallery with search, category filters and saved looks.
const looks = [
  {
    id: 1, title: "Denim Daydream", category: "Western", tag: "Everyday cool",
    subtitle: "Relaxed denim, polished basics",
    description: "An easy, confident everyday look built around classic denim and a clean silhouette.",
    tips: "Pair straight-leg jeans with a fitted white tee, a slim belt, simple hoops and sneakers or loafers.",
    image: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=900&q=85",
    keywords: "jeans denim shirt casual blue white everyday street style"
  },
  {
    id: 2, title: "Paris in Pink", category: "French", tag: "French chic",
    subtitle: "Soft colour, effortless elegance",
    description: "A romantic Paris-inspired outfit with a feminine palette and timeless styling.",
    tips: "Try a soft pink jacket with tailored trousers, ballet flats, a structured mini bag and delicate jewellery.",
    image: "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=900&q=85",
    keywords: "pink french paris chic jacket elegant street style"
  },
  {
    id: 3, title: "Desi Romance", category: "Desi", tag: "Desi elegance",
    subtitle: "Traditional details, modern grace",
    description: "A graceful Pakistani-inspired look for family gatherings, festive dinners and special days.",
    tips: "Style an embroidered kurta with straight trousers, a light dupatta, jhumkas and embellished khussas.",
    image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=900&q=85",
    keywords: "pakistani desi shalwar kameez traditional embroidered dupatta eid"
  },
  {
    id: 4, title: "The Dreamy Frock", category: "Frocks", tag: "Soft & dreamy",
    subtitle: "Flowing shapes, pretty details",
    description: "A dreamy dress mood for birthdays, dinners or any day you want to feel extra special.",
    tips: "Keep accessories delicate: small earrings, a dainty bracelet and a matching mini bag work beautifully.",
    image: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&w=900&q=85",
    keywords: "frock gown maxi dress pink party princess feminine"
  },
  {
    id: 5, title: "City Girl Uniform", category: "Western", tag: "Street style",
    subtitle: "A crisp shirt meets blue denim",
    description: "A versatile city outfit that feels relaxed but still looks thoughtfully put together.",
    tips: "Tuck a crisp shirt into jeans, add a leather-look belt, sunglasses and a shoulder bag.",
    image: "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=900&q=85",
    keywords: "jeans shirt western streetwear city girl blue denim"
  },
  {
    id: 6, title: "Festive Glow", category: "Desi", tag: "Occasion wear",
    subtitle: "A little sparkle goes a long way",
    description: "A dressed-up desi mood inspired by rich colour, delicate embroidery and celebration-ready details.",
    tips: "Choose one statement element, such as embroidered fabric or bold earrings, and keep the rest balanced.",
    image: "https://images.unsplash.com/photo-1583391733956-6c78276477e3?auto=format&fit=crop&w=900&q=85",
    keywords: "pakistani dress festive wedding formal desi embroidered"
  },
  {
    id: 7, title: "Classic in Cream", category: "Elegant", tag: "Quiet luxury",
    subtitle: "Minimal, timeless, elevated",
    description: "A refined neutral outfit for brunch, meetings, or whenever understated style feels right.",
    tips: "Mix cream, beige and chocolate tones. Add a structured bag and simple gold-tone jewellery.",
    image: "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=900&q=85",
    keywords: "cream beige neutral elegant luxury classy minimal outfit"
  },
  {
    id: 8, title: "Red-Hot Moment", category: "Elegant", tag: "Main character",
    subtitle: "Bold colour, confident energy",
    description: "A statement look for a party or evening out, inspired by the confidence of a striking red outfit.",
    tips: "Let the red do the talking. Pair it with simple heels, a small clutch and minimal jewellery.",
    image: "https://images.unsplash.com/photo-1539008835657-9e8e9680c956?auto=format&fit=crop&w=900&q=85",
    keywords: "red dress party glamorous elegant evening bold"
  },
  {
    id: 9, title: "Weekend Muse", category: "Western", tag: "Off-duty",
    subtitle: "Easy layers, effortless style",
    description: "A relaxed weekend outfit that is comfortable, modern and easy to make your own.",
    tips: "Layer a light jacket over a simple top, then finish with your favourite jeans and comfortable shoes.",
    image: "https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?auto=format&fit=crop&w=900&q=85",
    keywords: "weekend casual jacket jeans modern western relaxed"
  },
  {
    id: 10, title: "Garden Party", category: "Frocks", tag: "Romantic mood",
    subtitle: "Floral softness with a twist",
    description: "A light, romantic dress idea for daytime celebrations, garden parties and spring-inspired styling.",
    tips: "Add a small shoulder bag and simple sandals. A soft hair ribbon or pearl studs finish the look.",
    image: "https://images.unsplash.com/photo-1495385794356-15371f348c31?auto=format&fit=crop&w=900&q=85",
    keywords: "floral dress frock spring garden party feminine"
  },
  {
    id: 11, title: "Parisian Layers", category: "French", tag: "City classic",
    subtitle: "Tailored layers, easy confidence",
    description: "A city-ready French-inspired look built around timeless layers and clean lines.",
    tips: "Try a striped top, tailored trousers, a trench or blazer, loafers and a neat crossbody bag.",
    image: "https://images.unsplash.com/photo-1485968579580-b6d095142e6e?auto=format&fit=crop&w=900&q=85",
    keywords: "french paris trench coat striped shirt classic chic"
  },
  {
    id: 12, title: "Blush Hour", category: "Elegant", tag: "Pretty in pink",
    subtitle: "Soft pink with a luxe finish",
    description: "A feminine pink outfit idea for a dinner, celebration or a polished everyday moment.",
    tips: "Combine different pink shades with nude shoes and a small red or burgundy accessory for contrast.",
    image: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=900&q=85",
    keywords: "pink outfit elegant feminine fashion red blush"
  }
];

const lookGrid = document.getElementById("lookGrid");
const searchInput = document.getElementById("searchInput");
const clearSearch = document.getElementById("clearSearch");
const resultCount = document.getElementById("resultCount");
const emptyState = document.getElementById("emptyState");
const modal = document.getElementById("lookModal");
const favoriteCount = document.getElementById("favoriteCount");
const favoritesToggle = document.getElementById("favoritesToggle");
const menuToggle = document.getElementById("menuToggle");
const mainNav = document.querySelector(".main-nav");

let activeCategory = "All";
let showFavoritesOnly = false;
let currentLookId = null;
const favorites = new Set();

// Create a single outfit card.
function createLookCard(look) {
  const card = document.createElement("article");
  card.className = "look-card";
  card.tabIndex = 0;
  card.setAttribute("aria-label", `View ${look.title}`);
  card.innerHTML = `
    <div class="card-image-wrap">
      <img src="${look.image}" alt="${look.title} fashion inspiration" loading="lazy">
      <span class="card-badge">${look.tag}</span>
      <button class="save-button ${favorites.has(look.id) ? "saved" : ""}" aria-label="${favorites.has(look.id) ? "Remove from" : "Add to"} favourites" title="Save look">${favorites.has(look.id) ? "♥" : "♡"}</button>
      <div class="quick-view">VIEW THE LOOK ↗</div>
    </div>
    <div class="card-info">
      <div class="card-title-row"><h3 class="card-title">${look.title}</h3><span class="card-arrow">↗</span></div>
      <p class="card-subtitle">${look.subtitle}</p>
    </div>`;

  card.querySelector(".save-button").addEventListener("click", (event) => {
    event.stopPropagation();
    toggleFavorite(look.id);
  });
  card.addEventListener("click", () => openLook(look.id));
  card.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      if (event.target === card) {
        event.preventDefault();
        openLook(look.id);
      }
    }
  });
  return card;
}

// Show looks that match the selected category and search text.
function renderLooks() {
  const searchTerm = searchInput.value.trim().toLowerCase();
  const filteredLooks = looks.filter((look) => {
    const matchesCategory = activeCategory === "All" || look.category === activeCategory;
    const searchableText = `${look.title} ${look.category} ${look.tag} ${look.subtitle} ${look.description} ${look.tips} ${look.keywords}`.toLowerCase();
    const matchesSearch = searchableText.includes(searchTerm);
    const matchesFavorites = !showFavoritesOnly || favorites.has(look.id);
    return matchesCategory && matchesSearch && matchesFavorites;
  });

  lookGrid.innerHTML = "";
  filteredLooks.forEach((look) => lookGrid.appendChild(createLookCard(look)));
  emptyState.hidden = filteredLooks.length > 0;
  resultCount.textContent = showFavoritesOnly
    ? `${filteredLooks.length} saved ${filteredLooks.length === 1 ? "look" : "looks"}`
    : `${filteredLooks.length} ${filteredLooks.length === 1 ? "look" : "looks"} to inspire you`;
  clearSearch.style.display = searchTerm ? "block" : "none";
  favoritesToggle.classList.toggle("is-active", showFavoritesOnly);
}

// Add or remove a look from favourites.
function toggleFavorite(id) {
  if (favorites.has(id)) {
    favorites.delete(id);
  } else {
    favorites.add(id);
  }
  favoriteCount.textContent = favorites.size;
  if (currentLookId === id) updateModalFavoriteButton();
  renderLooks();
}

// Open the detailed outfit view.
function openLook(id) {
  const look = looks.find((item) => item.id === id);
  if (!look) return;
  currentLookId = id;
  document.getElementById("modalImage").src = look.image;
  document.getElementById("modalImage").alt = `${look.title} fashion inspiration`;
  document.getElementById("modalCategory").textContent = `${look.category} COLLECTION · ${look.tag}`;
  document.getElementById("modalTitle").textContent = look.title;
  document.getElementById("modalDescription").textContent = look.description;
  document.getElementById("modalTips").textContent = look.tips;
  document.getElementById("modalFavorite").style.display = "";
  updateModalFavoriteButton();
  modal.hidden = false;
  document.body.style.overflow = "hidden";
  document.getElementById("modalClose").focus();
}

function closeModal() {
  modal.hidden = true;
  document.body.style.overflow = "";
  currentLookId = null;
}

function updateModalFavoriteButton() {
  const button = document.getElementById("modalFavorite");
  const isSaved = favorites.has(currentLookId);
  button.textContent = isSaved ? "♥ Saved to favourites" : "♡ Save this look";
}

// Click a category filter.
document.querySelectorAll(".filter-chip").forEach((button) => {
  button.addEventListener("click", () => {
    activeCategory = button.dataset.category;
    document.querySelectorAll(".filter-chip").forEach((chip) => chip.classList.remove("active"));
    button.classList.add("active");
    renderLooks();
  });
});

searchInput.addEventListener("input", renderLooks);
clearSearch.addEventListener("click", () => {
  searchInput.value = "";
  renderLooks();
  searchInput.focus();
});
document.getElementById("resetFilters").addEventListener("click", () => {
  activeCategory = "All";
  showFavoritesOnly = false;
  searchInput.value = "";
  document.querySelectorAll(".filter-chip").forEach((chip) => chip.classList.toggle("active", chip.dataset.category === "All"));
  renderLooks();
});

favoritesToggle.addEventListener("click", () => {
  showFavoritesOnly = !showFavoritesOnly;
  renderLooks();
  if (showFavoritesOnly) {
    lookGrid.scrollIntoView({ behavior: "smooth", block: "start" });
  }
});

document.getElementById("modalClose").addEventListener("click", closeModal);
document.getElementById("modalCloseSecondary").addEventListener("click", closeModal);
document.getElementById("modalFavorite").addEventListener("click", () => {
  if (currentLookId !== null) toggleFavorite(currentLookId);
});
modal.addEventListener("click", (event) => {
  if (event.target === modal) closeModal();
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !modal.hidden) closeModal();
});

menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");
});
mainNav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => mainNav.classList.remove("open"));
});

// Draw the first gallery on page load.
renderLooks();


// ARU Muse photo viewer: open personal looks in the existing detail modal.
const museLooks = {
  turquoise: {
    image: "aru-muse-turquoise.jpg",
    alt: "ARU Muse in a turquoise outfit",
    category: "ARU MUSE · COLOUR MOOD",
    title: "Turquoise Chic",
    description: "A vibrant turquoise look with soft, feminine styling. The rich colour does the talking, so keep the rest of the styling polished and simple.",
    tips: "Pair jewel tones with delicate gold accessories, a neat manicure and understated shoes or a matching bag."
  },
  parisian: {
    image: "aru-muse-parisian-coat.jpg",
    alt: "ARU Muse in a camel coat, black top and dark jeans",
    category: "ARU MUSE · CITY CLASSIC",
    title: "Parisian Winter Chic",
    description: "A timeless camel coat layered over black with dark denim: an easy formula for a refined, city-ready outfit.",
    tips: "Add ankle boots or loafers, small hoops, a structured bag and a scarf on colder days."
  }
};
document.querySelectorAll("[data-muse]").forEach((button) => {
  button.addEventListener("click", () => {
    const look = museLooks[button.dataset.muse];
    if (!look) return;
    currentLookId = null;
    document.getElementById("modalImage").src = look.image;
    document.getElementById("modalImage").alt = look.alt;
    document.getElementById("modalCategory").textContent = look.category;
    document.getElementById("modalTitle").textContent = look.title;
    document.getElementById("modalDescription").textContent = look.description;
    document.getElementById("modalTips").textContent = look.tips;
    document.getElementById("modalFavorite").style.display = "none";
    modal.hidden = false;
    document.body.style.overflow = "hidden";
    document.getElementById("modalClose").focus();
  });
});
