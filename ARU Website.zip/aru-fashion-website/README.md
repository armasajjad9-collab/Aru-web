# ARU Fashion Inspiration Website

A beginner-friendly static website made with HTML, CSS, and vanilla JavaScript.

## Files
- `index.html` — page structure
- `style.css` — pink/red luxury magazine styling and responsive layout
- `script.js` — fashion gallery data, search, filters, favourites, and outfit detail modal

## Run it
1. Download and unzip `aru-fashion-website.zip`.
2. Open the `aru-fashion-website` folder.
3. Double-click `index.html` to open it in your browser.
4. For a smoother development experience, open the folder in VS Code and use the Live Server extension.

## Features
- Search outfit names, styles, colours and keywords.
- Filter by Western, Pakistani Desi, Frocks, French Chic and Elegant looks.
- Click any card to view outfit details and styling suggestions.
- Save favourite looks and filter to see only saved looks.
- Responsive layout for mobile, tablet and desktop.
- Uses remote Unsplash images and Google Fonts, so an internet connection is required for those assets.

## Customise it
To add a look, open `script.js` and add another object to the `looks` array. Give it a unique `id`, title, category, description, tips, image URL and keywords. The category should match one of the filter names used in `index.html`.

Note: this is a fashion inspiration gallery, not an online shop. Favourite selections are kept only while the page remains open; browser storage and accounts are not configured.


## ARU Muse
The homepage includes a personal-look section featuring the two supplied photos. Keep `aru-muse-turquoise.jpg` and `aru-muse-parisian-coat.jpg` alongside `index.html`. Click either photo to view styling tips.
